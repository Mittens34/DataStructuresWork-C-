#include "commands.h"
using namespace std;

Print::Print(NumericExpression* n)
{
	left = n;
}

Print::~Print()
{
	delete left;
}

string Print::format() const 
{
	return "PRINT " + left->format();
}

Let::Let(NumericExpression* l, Variable* v)
{
	left = l;
	var = v;
}

Let::~Let()
{
	delete left;
	delete var;
}

string Let::format() const 
{
	return "LET " + var->format() + " " + left->format();
}
Goto::Goto(LineNumber* l)
{
	ln = l;
}

Goto::~Goto()
{
	delete ln;
}

string Goto::format() const 
{
	return "GOTO <" + ln->format() + ">";
}

If::If(NumericExpression* l, LineNumber* lin)
{
	left = l;
	ln = lin;
}

If::~If()
{
	delete left;
	delete ln;
}

string If::format() const 
{
	return "IF " + left->format() + " THEN " + "<" + ln->format() + ">";
}

Gosub::Gosub(LineNumber* ne)
{
	
	next = ne;
}

Gosub::~Gosub()
{
	//delete previous;
	delete next;
}

string Gosub::format() const 
{
	return "GOSUB <" + next->format() + ">";
}

Return::Return(LineNumber* prev)
{
	previous = prev;
}

Return::~Return()
{
	delete previous;
}

string Return::format() const 
{
	return "RETURN";
}

End::End()
{

}

End::~End()
{
	
}

string End::format() const 
{
	return "END";
}