#include "lineNumber.h"
#include <string>
#include <sstream>
using namespace std;

LineNumber::LineNumber(string name, int pos, string lin) : Variable(name)
{
	value = pos;
	line = lin;
}

LineNumber::~LineNumber()
{
	//delete value;
	//delete line;	
}

int LineNumber::getLine()
{
	return value;
}

string LineNumber::getString()
{
	return line;
}

string LineNumber::format() const
{
	string out;
	stringstream ss;
	ss << value;
	out = ss.str();
	return out;
}