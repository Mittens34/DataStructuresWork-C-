#include "integer.h"
#include <string>
#include <sstream>
using namespace std;

Integer::Integer(string n, int* v) : Variable(n)
{
	value = v;
}

Integer::~Integer()
{
	delete value;
}

int Integer::getValue()
{
	return *value;
}

string Integer::format() const
{
	string out;
	stringstream ss;
	ss << *value;
	out = ss.str();
	return out;
}