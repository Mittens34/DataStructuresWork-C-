#ifndef INTERPRETER_HPP
#define INTERPRETER_HPP

#include <iostream>
#include <vector>
#include "arithmetic.h"

class Interpreter {
public:
    Interpreter(std::istream& in);
    ~Interpreter();
	NumericExpression* parseExpression(std::string line, std::vector<std::string> vect);
    void write(std::ostream& out);
    std::string removeSpaces(std::string str);
    std::string removeParent(std::string str , int arg);

private:
    void parse(std::istream& in);
    std::vector<std::string> output;
};

#endif
