#include "variable.h"
using namespace std;

Variable::Variable(string n)
{
	name = n;
}

Variable::~Variable()
{
	//delete name;
}

string Variable::getName()
{
	return name;
}

string Variable::format() const
{
	return name;
}