#ifndef INTEGER_H
#define INTEGER_H

#include <iostream>

#include "variable.h"

class Integer : public Variable
{
public:
	Integer(std::string, int*);
	virtual ~Integer();
	int getValue();
	virtual std::string format() const;
private:
	int* value;
};

#endif