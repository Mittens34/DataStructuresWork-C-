#ifndef COMMANDS_HPP
#define COMMANDS_HPP

#include <string>
#include "arithmetic.h"
#include "variable.h"
#include "array.h"
#include "lineNumber.h"
#include "integer.h"

class Commands 
{
public:
    virtual std::string format() const = 0;
};

class Print : public Commands
{
public:
    Print(NumericExpression* left);
    virtual ~Print();

    virtual std::string format() const;

private:
    NumericExpression* left;
};

class Let: public Commands 
{
public:
    Let(NumericExpression* l, Variable* v);
    virtual ~Let();

    virtual std::string format() const;

private:
    NumericExpression* left;
    Variable* var;
};

class Goto : public Commands
{
public:
    Goto(LineNumber* ln);
    virtual ~Goto();

    virtual std::string format() const;

private:
    LineNumber* ln;
};

class If : public Commands
{
public:
    If(NumericExpression* left, LineNumber* ln);
    virtual ~If();

    virtual std::string format() const;

private:
    NumericExpression* left;
    LineNumber* ln;
};

class Gosub : public Commands
{
public:
    Gosub(LineNumber* next);
    virtual ~Gosub();

    virtual std::string format() const;

private:
    //LineNumber* previous;
    LineNumber* next;
};

class Return : public Commands
{
public:
    Return(LineNumber* previous);
    virtual ~Return();

    virtual std::string format() const;

private:
    LineNumber* previous;
};

class End 
{
public:
    End();
    virtual ~End();

    virtual std::string format() const;
};


#endif
