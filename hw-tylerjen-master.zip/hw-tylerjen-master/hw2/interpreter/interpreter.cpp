#include "interpreter.h"
#include <vector>
#include "arithmetic.h"
#include "commands.h"
#include "variable.h"
#include "boolExpression.h"
#include "integer.h"
#include "array.h"
#include <sstream>
#include <algorithm>

using namespace std;

Interpreter::Interpreter(std::istream& in) 
{
    this->parse(in);
}

Interpreter::~Interpreter() 
{

}

void Interpreter::parse(std::istream& in) 
{
    string line;
    while (getline(in, line)) 
    {
        size_t line_number;
        stringstream stream(line);
        stream >> line_number;
        // Your code here
        LineNumber *l = new LineNumber("line", line_number, "line");
        output.push_back(l->format());
        string command;
        stream >> command;
        if(command == "PRINT")
        {
            string nexp;
            getline(stream, nexp);

            Print* prin = new Print(parseExpression(nexp, output));

            output.push_back(prin->format());
        }
        else if(command == "LET")//also let array
        {
            string restOfLine;
            getline(stream, restOfLine);
            size_t letArray = restOfLine.find("]");
            string nexp;
            string var;
            if(letArray != std::string::npos)
            {
                nexp = restOfLine.substr(letArray+1);
                var = restOfLine.substr(0, letArray+1);
                var = removeSpaces(var);
            }
            else
            {
                stringstream getRest(restOfLine);
                getRest >> var;
                getline(getRest, nexp);
            }
            Variable* v = new Variable(var);
            Let* le = new Let(parseExpression(nexp, output), v);
            output.push_back(le->format());
        }
		else if(command == "GOTO")//done
		{
            int lineJump;
            stream >> lineJump;
            LineNumber* jump = new LineNumber("lineJump", lineJump, "lineJump");
            Goto* got = new Goto(jump);
            output.push_back(got->format());
		} 
		else if(command == "IF")
		{
            string restOfLine;
            getline(stream, restOfLine);
            size_t bexpEnd = restOfLine.find("THEN");
            string lineJump = restOfLine.substr(bexpEnd + 4);
            int length = restOfLine.size() - lineJump.size() - 4;
            string nexp = restOfLine.substr(0, length);
            
            stringstream lineChange(lineJump);
            int lineJumpNumber;
            lineChange >> lineJumpNumber;
            
            LineNumber* lJump = new LineNumber("lineJump", lineJumpNumber, "line");

            If* ifThen = new If(parseBoolExpression(nexp, output), lJump);
            output.push_back(ifThen->format());
		}
		else if(command == "GOSUB")//done
		{
            int lineJump;
            stream >> lineJump;
            LineNumber* jump = new LineNumber("lineJump", lineJump, "lineJump");
            Gosub* gos = new Gosub(jump);
            output.push_back(gos->format());
		}
		else if(command == "RETURN")//done
		{
            Return* ret = new Return(l);
            output.push_back(ret->format());
		}
        else if(command == "END")//done
        {
        	End* end = new End();
        	output.push_back(end->format());
        }

    }
    
}

NumericExpression* Interpreter::parseExpression(string str, vector<string> vect)
{
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    if(str.at(0) == '(')
    {
        str = str.substr(1);
    }
    if(str.at(str.size() - 1) == ')')
    {
        str = str.substr(0, str.size() - 1);
    }
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    size_t lastParent = str.rfind(')');
    size_t arrStart = str.find("[", lastParent);
    size_t arrEnd = str.find("]", lastParent);

    if(lastParent == std::string::npos)
    {
        removeParent(str, 0);
    }
    size_t pos = str.find("+",lastParent);
    size_t pos1 = str.find("-",lastParent);
    size_t pos2 = str.find("*",lastParent);
    size_t pos3 = str.find("/",lastParent);
    
    if((pos > arrStart) & (pos < arrEnd))
    {
        pos = str.find("+", arrEnd);
    }
    if((pos1 > arrStart) & (pos1 < arrEnd))
    {
        pos1 = str.find("-", arrEnd);
    }
    if((pos2 > arrStart) & (pos2 < arrEnd))
    {
        pos2 = str.find("*", arrEnd);
    }
    if((pos3 > arrStart) & (pos3 < arrEnd))
    {
        pos3 = str.find("/", arrEnd);
    }

    if(pos != std::string::npos)
    {
        string left = str.substr(0, pos);
        string right = str.substr(pos+1);
        AdditionExpression* add = new AdditionExpression(parseExpression(left, vect),parseExpression(right,vect));
        return add;
    }
    else if((pos1 != std::string::npos) & (str.at(pos1+1) == ' '))
    {
        string left = str.substr(0, pos1);
        string right = str.substr(pos1+1);
        SubtractionExpression* subt = new SubtractionExpression(parseExpression(left, vect),parseExpression(right, vect));
        return subt;
    }
    else if(pos2 != std::string::npos)
    {
        string left = str.substr(0, pos2);
        string right = str.substr(pos2+1);
        MultiplicationExpression* multi = new MultiplicationExpression(parseExpression(left, vect),parseExpression(right, vect));
        return multi;
    }
    else if(pos3 != std::string::npos)
    {
        string left = str.substr(0, pos3);
        string right = str.substr(pos3+1);
        DivisionExpression* div = new DivisionExpression(parseExpression(left, vect),parseExpression(right, vect));
        return div;
    }
    else if(arrStart != std::string::npos)
    {
        string inBrackets = str.substr(arrStart + 1, arrEnd - arrStart - 1);
        string name = str.substr(0, arrStart);
        Array* ar = new Array(name, parseExpression(inBrackets, vect));
        return ar;
    }
    else
    {
        pos = str.rfind("+");
        pos1 = str.rfind("-");
        pos2 = str.rfind("*");
        pos3 = str.rfind("/");
        arrStart = str.find("[");
        arrEnd = str.find("]");

        if((arrEnd == str.size() - 1) & (str.find("[") < pos1))
        {
            arrStart = str.find("[");
        }
        if((arrEnd == str.size() - 1) & (str.find("[") < pos))
        {
            arrStart = str.find("[");
        }
        if((arrEnd == str.size() - 1) & (str.find("[") < pos2))
        {
            arrStart = str.find("[");
        }
        if((arrEnd == str.size() - 1) & (str.find("[") < pos3))
        {
            arrStart = str.find("[");
        }
        
        if((pos > arrStart) & (pos < arrEnd))
        {
            pos = str.find("+", arrEnd);
        }
        if((pos1 > arrStart) & (pos1 < arrEnd))
        {
            pos1 = str.find("-", arrEnd);
        }
        if((pos2 > arrStart) & (pos2 < arrEnd))
        {
            pos2 = str.find("*", arrEnd);
        }
        if((pos3 > arrStart) & (pos3 < arrEnd))
        {
            pos3 = str.find("/", arrEnd);
        }

        if(pos != std::string::npos)
        {
            string left = str.substr(0, pos);
            string right = str.substr(pos+1);
            NumericExpression* r = parseExpression(right, vect);
            AdditionExpression* add = new AdditionExpression(parseExpression(left, vect),r);
            return add;
        }
        else if((pos1 != std::string::npos) & (str.at(pos1+1) == ' '))
        {
            string left = str.substr(0, pos1);
            string right = str.substr(pos1+1);
            NumericExpression* r = parseExpression(right, vect);
            SubtractionExpression* subt = new SubtractionExpression(parseExpression(left, vect), r);
            return subt;
        }
        else if(pos2 != std::string::npos)
        {
            string left = str.substr(0, pos2);
            string right = str.substr(pos2+1);
            NumericExpression* r = parseExpression(right, vect);
            MultiplicationExpression* multi = new MultiplicationExpression(parseExpression(left, vect), r);
            return multi;
        }
        else if(pos3 != std::string::npos)
        {
            string left = str.substr(0, pos3);
            string right = str.substr(pos3+1);
            NumericExpression* r = parseExpression(right, vect);
            DivisionExpression* div = new DivisionExpression(parseExpression(left, vect), r);
            return div;
        }
        else if(arrStart != std::string::npos)
        {
            string inBrackets = str.substr(arrStart + 1, arrEnd - arrStart - 1);

            string name = str.substr(0, arrStart);
            Array* ar = new Array(name, parseExpression(inBrackets, vect));
            return ar;
        }
        else
        {
            
            if(str.at(0) == '-')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '0')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '1')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '2')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '3')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '4')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '5')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '6')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '7')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '8')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '9')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else
            {
                Variable* var = new Variable(str);
                return var;
            }
        }
    }

}

BoolExpression* Interpreter::parseBoolExpression(string str, vector<string> vect)
{
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    if(str.at(0) == '(')
    {
        str = str.substr(1);
    }
    if(str.at(str.size() - 1) == ')')
    {
        str = str.substr(0, str.size() - 1);
    }
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    size_t lastParent = str.rfind(')');


    size_t bool1 = str.find("=",lastParent);
    size_t bool2 = str.find("<",lastParent);
    size_t bool3 = str.find(">",lastParent);

    if(bool1 != std::string::npos)
    {
        string left = str.substr(0, bool1);
        string right = str.substr(bool1+1);
        EqualsExpression* equa = new EqualsExpression(parseExpression(left, vect), parseExpression(right, vect));
        return equa;
    }
    else if(bool2 != std::string::npos)
    {
        string left = str.substr(0, bool2);
        string right = str.substr(bool2+1);
        LesserExpression* lesse = new LesserExpression(parseExpression(left, vect),parseExpression(right, vect));
        return lesse;
    }
    else if(bool3 != std::string::npos)
    {
        string left = str.substr(0, bool3);
        string right = str.substr(bool3+1);
        GreaterExpression* grea = new GreaterExpression(parseExpression(left, vect),parseExpression(right, vect));
        return grea;
    }
    else
    {

        bool1 = str.rfind("=");
        bool2 = str.rfind("<");
        bool3 = str.rfind(">");

        if(bool1 != std::string::npos)
        {
            string left = str.substr(0, bool1);
            string right = str.substr(bool1+1);
            NumericExpression* r = parseExpression(right, vect);
            EqualsExpression* equa = new EqualsExpression(parseExpression(left, vect), r);
            return equa;
        }
        else if(bool2 != std::string::npos)
        {
            string left = str.substr(0, bool2);
            string right = str.substr(bool2+1);
            NumericExpression* r = parseExpression(right, vect);
            LesserExpression* lesse = new LesserExpression(parseExpression(left, vect),r);
            return lesse;
        }
        else if(bool3 != std::string::npos)
        {
            string left = str.substr(0, bool3);
            string right = str.substr(bool3+1);
            NumericExpression* r = parseExpression(right, vect);
            GreaterExpression* grea = new GreaterExpression(parseExpression(left, vect),r);
            return grea;
        }
    }
}

std::string Interpreter::removeSpaces(std::string str)
{
    str.erase(remove(str.begin(), str.end(), ' '), str.end());
    return str;
}

std::string Interpreter::removeParent(std::string str , int arg)
{
    if(arg == 0)
    {
        str.erase(remove(str.begin(), str.end(), '('), str.end());
        return removeParent(str, 1);
    }
    else
    {
        str.erase(remove(str.begin(), str.end(), ')'), str.end());
        return str;
    }
    
}

void Interpreter::write(std::ostream& out) 
{
    std::string space = " ";
    int si = output.size();
    int i = 1;
    for(int z = 0; z < si; z++)
    {
        out << output[z];
        if(z != si-1)
        {
            out << space;
            if(i%2 == 0)
            {
                out << endl;
            }
            i++;
        }
    }
    out << endl;
}