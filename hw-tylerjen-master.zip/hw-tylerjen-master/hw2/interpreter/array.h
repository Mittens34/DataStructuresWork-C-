#ifndef ARRAY_H
#define ARRAY_H

#include <iostream>
#include <vector>
#include "variable.h"

class Array : public Variable
{
public:
	Array(std::string name, NumericExpression* nexp);
	virtual ~Array();
	void setVal(int, int);
	int getVal(int);
	virtual std::string format() const;
private:
	NumericExpression* nexp; 
	std::vector<int> vect;
};

#endif