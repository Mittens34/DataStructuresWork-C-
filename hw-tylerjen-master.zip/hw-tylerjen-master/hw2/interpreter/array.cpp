#include "array.h"

using namespace std;

#include <vector>

Array::Array(string n, NumericExpression* ne) : Variable(n)
{
	nexp = ne;
	std::vector<int> vect();
}
void Array::setVal(int pos, int val)
{
	vect[pos] = val;
}
int Array::getVal(int pos)
{
	return vect[pos];
}
Array::~Array()
{
	delete nexp;

}
string Array::format() const
{
	return this->name + "[" + nexp->format() + "]";
}