#include "boolExpression.h"
#include "arithmetic.h"

using namespace std;


BoolExpression::BoolExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

BoolExpression::~BoolExpression() {
    delete this->left;
    delete this->right;
}

string EqualsExpression::format() const {
    return "(" + this->left->format() + " = " + this->right->format() + ")";
}

BoolExpression::BoolExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

EqualsExpression::~EqualsExpression() {
    delete this->left;
    delete this->right;
}

string EqualsExpression::format() const {
    return "(" + this->left->format() + " = " + this->right->format() + ")";
}

GreaterExpression::GreaterExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

GreaterExpression::~GreaterExpression() {
    delete this->left;
    delete this->right;
}

string GreaterExpression::format() const {
    return "(" + this->left->format() + " > " + this->right->format() + ")";
}

LesserExpression::LesserExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {
}

LesserExpression::~LesserExpression() {
    delete this->left;
    delete this->right;
}

string LesserExpression::format() const {
    return "(" + this->left->format() + " < " + this->right->format() + ")";
}