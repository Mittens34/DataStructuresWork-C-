#ifndef LINENUMBER_H
#define LINENUMBER_H

#include "variable.h"

#include <iostream>

class LineNumber : public Variable
{
public:
	LineNumber(std::string, int, std::string);
	virtual ~LineNumber();
	int getLine();
	std::string getString();
	virtual std::string format() const;
private:
	int value;
	std::string line;
};

#endif