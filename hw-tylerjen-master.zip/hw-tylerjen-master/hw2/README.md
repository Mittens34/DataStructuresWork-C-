Nothing additional to add, everything should work as expected







Verify Steps:


Please make sure you have read and understood the submission instructions.
Go to your home directory: $ cd ~
Create a verify directory: $ mkdir verify
Go into that directory: $ cd verify
Clone your hw-username repo: $ git clone git@github.com:https://github.com/usc-csci104-fall2019/hw-username.git
Go into your folder: $ cd hw-username/
Recompile and rerun your programs and tests to ensure that what you submitted works.
Go to the Assignments page and click on the submission link.
Find your full commit SHA (not just the 7 digit summary) and paste the full commit SHA into the textbox on the submission page.
Click Submit via Github
Click Check My Submission to ensure what you are submitting compiles and passes any basic tests we have provided.
