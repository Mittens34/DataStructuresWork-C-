#include "heap.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
	MinHeap<int> test(2);
	test.add(7, 2);
	int id = test.add(8, 3);
	test.add(10, 4);
	cout << "POP: " << test.peek() << endl;

	test.add(3, 1);
	cout << "POP: " << test.peek() << endl;

	test.add(10, 2);
	test.remove();
	cout << "POP: " << test.peek() << endl;

	test.update(id, 0);
	cout << "POP: " << test.peek() << endl;

	MinHeap<string> testString(2);
	testString.add("hello", 0);
	cout << testString.peek() << endl;

	testString.remove();
}