#include <iostream>
#include <sstream>
#include <fstream>
#include <queue>

using namespace std;

struct course
{
	string name;
	double work;
	double learn;
};

double backTrack(int index, double work, double totalLearn, 
	double max, int classTotal, vector<course> classes)
{
	//temp value for what has been learned so far
	double max2 = totalLearn;

	if(totalLearn == max)
	{
		//hit max potential learned
		return max;
	}
	if(classTotal == index)
	{
		//iterated through all classes
		return totalLearn;
	}

	course temp = classes[index];

	if(temp.work + work > max)
	{
		//check if it exceeds max to be learned
		double learn2 = backTrack(index+1, work, 
			totalLearn, max, classTotal, classes);
		if(learn2 > max2)
		{
			max2 = learn2;
		}
		return max2;
	}
	else
	{
		//means this class can be added
		double learn2 = backTrack(index+1, temp.work+work, 
			totalLearn+temp.learn, max, classTotal, classes);
		if(learn2 > max2)
		{
			max2 = learn2;
		}
	}
	//finds the overall max through all possible combinations
	return max2;
}


int main(int argc, char* argv[])
{
	vector<course> classes;
	if (argc < 2) 
	{
        cerr << "Please provide an input file." << endl;
        return 1;
    }

	ifstream in;
	in.open(argv[1]);
	if(!in)
	{
		cout << "Invalid file" << endl;
		return -1;
	}
	else
	{
		int totalClasses;
		in >> totalClasses;

		double totalWork;
		in >> totalWork;
		course temp;

		//get all classes
		for(int i = 0; i < totalClasses; i++)
		{
			string name;
			in >> name;
			double work;
			in >> work;
			double learn;
			in >> learn;

			temp.name = name;
			temp.work = work;
			temp.learn = learn;

			classes.push_back(temp);
		}
		double m = backTrack(0, 0, 0, totalWork, totalClasses, classes);
		cout << m << endl;
	}

}