#include <vector>
#include <iostream>

template <typename T>
class MinHeap 
{
   public:
     MinHeap (int d): dsize(d)
     {
      numAdd = -1;
      elements = 0;
     }
     /* Constructor that builds a d-ary Min Heap
        This should work for any d >= 2,
        but doesn't have to do anything for smaller d.*/

     ~MinHeap ()
     {

     }

     int add (T item, int priority)
     {
       /* adds the item to the heap, with the given priority. 
          multiple identical items can be in the heap simultaneously. 
          Returns the number of times add has been called prior to this
          call (for use with the update function).*/
        Item it;
        it.val = item;
        it.prio = priority;
        numAdd++;

        it.nth = numAdd;

        elements++;
        

        eList.push_back(it);
        nthItem.push_back(elements - 1);

        up(elements-1);
        return numAdd;
     }

     const T & peek () const
     {
      return eList[0].val; 
      //I already sort for 2 elements being equal in up/down methods
       /* returns the element with smallest priority.  
          If two elements have the same priority, use operator< on the 
          T data, and return the one with smaller data.*/
     }

     void remove ()
     {
       /* removes the element with smallest priority, with the same tie-breaker
          as peek. */
        Item temp = eList[0];

        if(elements == 1)
        {
          eList.pop_back();
          elements--;
          nthItem[temp.nth] = -1;
        }
        else if (elements < 1)
        {
          return;
        }
        else
        {
          swap(0, elements-1);
          eList.pop_back();
          elements--;

          down(0);

          nthItem[temp.nth] = -1;
        }
     }

     void update (int nth, int priority)
     {
       /* finds the nth item (where nth is 0-based) that has ever been added 
          to the heap (the node that was created on the nth call to add), 
          and updates its priority accordingly. */
        if(nthItem[nth] == -1)
        {
          return;
        }
        Item temp = eList[nthItem[nth]];
        temp.prio = priority;

        eList[nthItem[nth]] = temp;

        up(nthItem[nth]);
        down(nthItem[nth]);
     }

     bool isEmpty ()
     {
        /* returns true iff there are no elements on the heap. */
        if(elements == 0)
        {
          return true;
        }
        else
        {
          return false;
        }
     }

 private:
    // whatever you need to naturally store things.
    // You may also add helper functions here.
  struct Item
  {
    T val;
    int prio;
    int nth;
  };

  int dsize;
  int elements;
  int numAdd;
  std::vector<Item> eList;
  std::vector<int> nthItem;

  void up(int pos)
  {
    if(pos <= 0)
    {
      return;
    }
    
    int parent = (pos - 1) / dsize;
    Item par = eList[parent];
    Item it = eList[pos];

    if(it.prio <= par.prio)
    {
      if(it.prio == par.prio)
      {
        if(it.val < par.val)
        {
          swap(pos, parent);
          up(parent);
        }
      }
      else
      {
        swap(pos, parent);
        up(parent);
      }
    }

    
  }

  void down(int pos)
  {
    
    Item it = eList[pos];
    int chi = smallestChild(pos);
    Item child = eList[chi];

    if(child.prio <= it.prio)
    {
      if(child.prio == it.prio)
      {
        if(child.val < it.val)
        {
          swap(pos, chi);
          down(chi);
        }
        else
        {
          return;
        }
      }
      else
      {
        swap(pos, chi);
        down(chi);
      }
    }
  }

  int smallestChild(int pos)
  {
    int child = (dsize * pos);
    int smallest = child;
    for(int i = 1; i < dsize; i++)
    {
      child = (dsize * pos) + i;
      Item chi = eList[child];
      if(chi.prio <= eList[smallest].prio)
      {
        if(chi.prio == eList[smallest].prio)
        {
          if(chi.val < eList[smallest].val)
          {
            smallest = child;
          }
        }
        else
        {
          smallest = child;
        }
      }
    }
    return smallest;
  }

  void swap(int pos1, int pos2)
  {
    Item one = eList[pos1];
    Item two = eList[pos2];

    eList[pos1] = two;
    eList[pos2] = one;


    nthItem[one.nth] = pos2;
    nthItem[two.nth] = pos1; 

  }
};