#include <iostream>
#include <vector>
#include <map>
#include <sstream>
#include <fstream>

#include "heap.h"

using namespace std;

struct GraphNode
{
	string name;
	vector<int> connected;
	int heur;
};

void graphCreate(vector<GraphNode> &nodes, map<string, int> neighborMap)
{
	for(unsigned int i = 0; i < nodes.size(); i++)
	{
		string word = nodes[i].name;

		for(unsigned int j = 0; j < word.length(); j++)
		{
			string s = word;
			for(char c = 'A'; c <= 'Z'; c++)
			{
				s[j] = c;
				if(s == word)
				{
	
				}
				else
				{
					map<string,int>::iterator it = neighborMap.find(s);
					if(it != neighborMap.end())
					{
						int neighbor = it->second;
						it = neighborMap.find(word);
						nodes[it->second].connected.push_back(neighbor);
					}
				}
			}
		}
	}
}

void uppercase(string &s)
{
	for(unsigned int i = 0; i < s.length(); i++)
	{
		if((s[i] >= 'a') && (s[i] <= 'z'))
		{
			s[i] = 'A' + (s[i] - 'a');
		}
	}
}

int heuristic(string end, string compare)
{
	int heur = 0;
	for(unsigned int i = 0; i < end.length(); i++)
	{
		if(end[i] != compare[i])
		{
			heur++;
		}
	}
	return heur;
}

void aStarSearch(vector<GraphNode> &nodes, map<string, int> 
	neighborMap, int startingWordIndex, string end)
{
	MinHeap<string> heap(2);

	int steps = 0;
	int expansions = 0;
	int visited[nodes.size()];
	int removed[nodes.size()];
	int added[nodes.size()];

	for(unsigned int j = 0; j < nodes.size(); j++)
	{
		visited[j] = 0;
		removed[j] = 0;
		added[j] = 0;
	}

	heap.add(nodes[startingWordIndex].name, 0);

	while(!heap.isEmpty())
	{
		
		string temp = heap.peek();
		startingWordIndex = neighborMap[temp];

		if(temp == end)
		{
			cout << steps << endl;
			cout << expansions << endl;
		}

		removed[startingWordIndex] = 1;
		heap.remove();
		steps++;

		for(unsigned int i = 0; i < nodes[startingWordIndex].connected.size(); i++)
		{
			int indx = nodes[startingWordIndex].connected[i];

			GraphNode w = nodes[indx];

			int h = heuristic(end, w.name);
			int f = steps + h;
			f = f * (end.size() + 1) + h;

			if(removed[indx] == 0)
			{
				if(visited[indx] == 0)
				{
					added[indx] = heap.add(w.name, f);
					expansions++;
					visited[indx] = 1;
				}
				else
				{
					heap.update(added[indx], f);
				}
			}
			
		}
	}
}

int main(int argc, char* argv[])
{
	if (argc < 4) 
	{
        cerr << "Please provide an input file." << endl;
        return 1;
    }

    string startWord = string(argv[1]);
    uppercase(startWord);
    string endWord = string(argv[2]);
    uppercase(endWord);

	ifstream inFile;

	inFile.open(argv[3]);

	if(!inFile)
	{
		cout << "Invalid file" << endl;
		return -1;
	}

	int steps = 0;
	int expansions = 0;
	int index = 0;
	int startingWordIndex;

	vector<GraphNode> graph;
	map<string, int> nodeIndex;

	if(startWord == endWord)
	{
		cout << steps << endl;
		cout << expansions << endl;
	}
	else
	{
		int numWords;
		inFile >> numWords;


		for(int i = 0; i < numWords; i++)
		{
			string word;
			inFile >> word;

			uppercase(word);

			if(word.length() != startWord.length())
			{
				continue;
			}
			else
			{
				int heuris = heuristic(endWord, word);
				GraphNode next;
				next.heur = heuris;
				next.name = word;

				graph.push_back(next);
				nodeIndex.insert(pair<string,int> (word, index));

				if(word == startWord)
				{
					startingWordIndex = index;
				}
				index++;
			}
		}
		graphCreate(graph, nodeIndex);

		aStarSearch(graph, nodeIndex, startingWordIndex, endWord);
	}
	return 0;
}