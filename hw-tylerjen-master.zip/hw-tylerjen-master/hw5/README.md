hw5.txt answer is in the file titled "IMG-2759.jpg"
to view with ease please download the file and it will open the full image


unfortunatley I was unable to finish the astarsearch function in my doublet.cpp. I was just confused with the logic and altering Dijkstra's algorithm. 
