#ifndef SPLAY_H
#define SPLAY_H

#include <iostream>
#include <cstdlib>
#include <string>
#include <math.h>
#include "../bst/bst.h"

/**
* A templated binary search tree implemented as a Splay tree.
*/
template <class Key, class Value>
class SplayTree : public BinarySearchTree<Key, Value>
{
public:
	// Methods for inserting/removing elements from the tree. You must implement
	// both of these methods.
	SplayTree();
	virtual void insert(const std::pair<Key, Value>& keyValuePair) override;
	void remove(const Key& key);
	int report() const;

private:
	/* You'll need this for problem 5. Stores the total number of inserts where the
	   node was added at level strictly worse than 2*log n (n is the number of nodes
	   including the added node. The root is at level 0). */
	int badInserts;
	int numNodes;

	/* Helper functions are encouraged. */
	Node<Key, Value>* rotateL(Node<Key, Value>* node);
	Node<Key, Value>* rotateR(Node<Key, Value>* node);
	void rebalance(Node<Key, Value>* node);

};

/*
--------------------------------------------
Begin implementations for the SplayTree class.
--------------------------------------------
*/

template<typename Key, typename Value>
SplayTree<Key, Value>::SplayTree() : badInserts(0) { }

template<typename Key, typename Value>
int SplayTree<Key, Value>::report() const {
	return badInserts;
}

template<typename Key, typename Value>
void SplayTree<Key, Value>::rebalance(Node<Key, Value>* node)
{
	Node<Key, Value>* par = node->getParent();

	if(!par)
	{
		this->mRoot = node;
		return;
	}

	Node<Key, Value>* par2 = par->getParent();
	if(!par2)
	{
		if(par->getLeft() == node)
		{
			rotateR(par);
		}
		else
		{
			rotateL(par);
		}
		this->mRoot = node;
		return;
	}
	else if(par2->getLeft() == par)
	{
		if(par->getLeft() == node)
		{
			rotateR(par2);
			rotateR(par);
		}
		else
		{
			rotateL(par);
			rotateR(par2);
		}
		rebalance(node);
	} 
	else
	{
		if(par->getLeft() == node)
		{
			rotateR(par);
			rotateL(par2);
		}
		else
		{
			rotateL(par2);
			rotateL(par);
		}
		rebalance(node);
	}
}

/**
* Insert function for a key value pair. Finds location to insert the node and then splays it to the top.
*/
template<typename Key, typename Value>
void SplayTree<Key, Value>::insert(const std::pair<Key, Value>& keyValuePair)
{
	// TODO
	int inserts = 0;
	numNodes++;
	bool hit = false;
	double logVal = 2 * log(numNodes);

	Node<Key, Value>* temp = this->mRoot;
	Key k = keyValuePair.first;
	Value v = keyValuePair.second;

	if(this->mRoot == NULL)
	{
		Node<Key, Value>* add = new Node<Key, Value>(k, v, NULL);
		this->mRoot = add;
	}
	else
	{
		while((temp->getLeft() != NULL) || (temp->getRight() != NULL))
		{
			inserts++;
			if(!hit)
			{
				if(logVal < inserts)
				{
					badInserts++;
					hit = true;
				}
			}
			

			if(keyValuePair.first < temp->getKey())
			{
				if(temp->getLeft() == NULL)
				{
					Node<Key, Value>* add = new Node<Key, Value>(k, v, temp);
					temp->setLeft(add);
					rebalance(add);
					return;
				}
				temp = temp->getLeft();
			}
			else if(keyValuePair.first > temp->getKey())
			{
				if(temp->getRight() == NULL)
				{
					Node<Key, Value>* add = new Node<Key, Value>(k, v, temp);
					temp->setRight(add);
					rebalance(add);
					return;
				}
				temp = temp->getRight();
			}
			else if(keyValuePair.first == temp->getKey())
			{
				temp->setValue(keyValuePair.second);
				rebalance(temp);
				return;
			}
		}
		if(keyValuePair.first < temp->getKey())
		{
			if(temp->getLeft() == NULL)
			{
				Node<Key, Value>* add = new Node<Key, Value>(k, v, temp);
				temp->setLeft(add);
				rebalance(add);
				return;
			}
			temp = temp->getLeft();
		}
		else if(keyValuePair.first > temp->getKey())
		{
			if(temp->getRight() == NULL)
			{
				Node<Key, Value>* add = new Node<Key, Value>(k, v, temp);
				temp->setRight(add);
				rebalance(add);
				return;
			}
			temp = temp->getRight();
		}
		else if(keyValuePair.first == temp->getKey())
		{
			temp->setValue(keyValuePair.second);
			rebalance(temp);
			return;
		}
	}
}

/**
* Remove function for a given key. Finds the node, reattaches pointers, and then splays the parent
* of the deleted node to the top.
*/
template<typename Key, typename Value>
void SplayTree<Key, Value>::remove(const Key& key)
{
	// TODO
	Node<Key, Value>* rem = this->internalFind(key);

	if(!rem)
	{
		return;
	}

	if(this->mRoot->getKey() == key)
	{
		this->removeNode(this->mRoot, key);
		rebalance(this->mRoot);
	}
	else
	{
		this->removeNode(this->mRoot, key);
		rebalance(rem->getParent());
	}

	numNodes--;
}

//left rotation of node
template<typename Key, typename Value>
Node<Key, Value>* SplayTree<Key, Value>::rotateL(Node<Key, Value>* node)
{
	Node<Key, Value>* temp = node->getRight();
    
    node->setRight(temp->getLeft()); 
    temp->setParent(node->getParent());

    Node<Key, Value>* par = temp->getParent();
 
    if (node->getRight() != NULL)
    {
        node->getRight()->setParent(node);
    }
 
    temp->setLeft(node);
    node->setParent(temp);
 
    if (par != NULL) 
    {
        if (par->getRight() == node) 
        {
            par->setRight(temp);
        }
        else 
        {
            par->setLeft(temp);
        }
    }
 	return temp;
}

//Same as previous method but flipped Left and Right methods
template<typename Key, typename Value>
Node<Key, Value>* SplayTree<Key, Value>::rotateR(Node<Key, Value>* node)
{
	Node<Key, Value> *temp = node->getLeft();

    node->setLeft(temp->getRight()); 
    temp->setParent(node->getParent());

    Node<Key, Value>* par = temp->getParent();
 
    if (node->getLeft() != NULL)
    {
        node->getLeft()->setParent(node);
    }
 
    temp->setRight(node);
    node->setParent(temp);
 
    if (par != NULL) 
    {
        if (par->getRight() == node) 
        {
            par->setRight(temp);
        }
        else 
        {
            par->setLeft(temp);
        }
    }
    return temp;
}


/*
------------------------------------------
End implementations for the SplayTree class.
------------------------------------------
*/

#endif
