#ifndef AVLBST_H
#define AVLBST_H

#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <string>
#include "../bst/bst.h"

/**
* A special kind of node for an AVL tree, which adds the height as a data member, plus 
* other additional helper functions. You do NOT need to implement any functionality or
* add additional data members or helper functions.
*/
template <typename Key, typename Value>
class AVLNode : public Node<Key, Value>
{
public:
	// Constructor/destructor.
	AVLNode(const Key& key, const Value& value, AVLNode<Key, Value>* parent);
	virtual ~AVLNode();

	// Getter/setter for the node's height.
	int getHeight() const;
	void setHeight(int height);

	// Getters for parent, left, and right. These need to be redefined since they 
	// return pointers to AVLNodes - not plain Nodes. See the Node class in bst.h
	// for more information.
	virtual AVLNode<Key, Value>* getParent() const override;
	virtual AVLNode<Key, Value>* getLeft() const override;
	virtual AVLNode<Key, Value>* getRight() const override;

protected:
	int mHeight;
};

/*
--------------------------------------------
Begin implementations for the AVLNode class.
--------------------------------------------
*/

/**
* Constructor for an AVLNode. Nodes are initialized with a height of 0.
*/
template<typename Key, typename Value>
AVLNode<Key, Value>::AVLNode(const Key& key, const Value& value, AVLNode<Key, Value>* parent)
	: Node<Key, Value>(key, value, parent)
	, mHeight(0)
{

}

/**
* Destructor.
*/
template<typename Key, typename Value>
AVLNode<Key, Value>::~AVLNode()
{

}

/**
* Getter function for the height. 
*/
template<typename Key, typename Value>
int AVLNode<Key, Value>::getHeight() const
{
	return mHeight;
}

/**
* Setter function for the height. 
*/
template<typename Key, typename Value>
void AVLNode<Key, Value>::setHeight(int height)
{
	mHeight = height;
}

/**
* Getter function for the parent. Used since the node inherits from a base node.
*/
template<typename Key, typename Value>
AVLNode<Key, Value>* AVLNode<Key, Value>::getParent() const
{
	return static_cast<AVLNode<Key,Value>*>(this->mParent);
}

/**
* Getter function for the left child. Used since the node inherits from a base node.
*/
template<typename Key, typename Value>
AVLNode<Key, Value>* AVLNode<Key, Value>::getLeft() const
{
	return static_cast<AVLNode<Key,Value>*>(this->mLeft);
}

/**
* Getter function for the right child. Used since the node inherits from a base node.
*/
template<typename Key, typename Value>
AVLNode<Key, Value>* AVLNode<Key, Value>::getRight() const
{
	return static_cast<AVLNode<Key,Value>*>(this->mRight);
}

/*
------------------------------------------
End implementations for the AVLNode class.
------------------------------------------
*/

/**
* A templated balanced binary search tree implemented as an AVL tree.
*/
template <class Key, class Value>
class AVLTree : public BinarySearchTree<Key, Value>
{
public:
	// Methods for inserting/removing elements from the tree. You must implement
	// both of these methods. 
	virtual void insert(const std::pair<Key, Value>& keyValuePair) override;
	void remove(const Key& key);

private:
	/* Helper functions are strongly encouraged to help separate the problem
	   into smaller pieces. You should not need additional data members. */
	void rebalance(AVLNode<Key, Value>* node);
	int adjustHeight(AVLNode<Key, Value>* node);

	AVLNode<Key, Value>* rotateL(AVLNode<Key, Value>* node);
	AVLNode<Key, Value>* rotateR(AVLNode<Key, Value>* node);
	AVLNode<Key, Value>* rotateLR(AVLNode<Key, Value>* node);
	AVLNode<Key, Value>* rotateRL(AVLNode<Key, Value>* node);
};

/*
--------------------------------------------
Begin implementations for the AVLTree class.
--------------------------------------------
*/

/**
* Insert function for a key value pair. Finds location to insert the node and then balances the tree. 
*/
template<typename Key, typename Value>
void AVLTree<Key, Value>::insert(const std::pair<Key, Value>& keyValuePair)
{
	Key k = keyValuePair.first;
	Value v = keyValuePair.second;
	AVLNode<Key, Value>* temp = static_cast<AVLNode<Key, Value>*>(this->mRoot);


	if(this->mRoot == NULL)
	{
		AVLNode<Key, Value>* add = new AVLNode<Key, Value>(k,v,NULL);
		this->mRoot = add;
		rebalance(add);
	}
	else
	{
		while((temp->getLeft() != NULL) || (temp->getRight() != NULL))
		{
			
			if(k < temp->getKey())
			{
				if(temp->getLeft() == NULL)
				{
					AVLNode<Key, Value>* add = new AVLNode<Key, Value>(k, v, temp);
					temp->setLeft(add);
					add->setHeight(adjustHeight(add));

					rebalance(temp);
					return;
				}
				temp = temp->getLeft();
			}
			else if(k > temp->getKey())
			{
				if(temp->getRight() == NULL)
				{
					AVLNode<Key, Value>* add = new AVLNode<Key, Value>(k, v, temp);
					temp->setRight(add);
					add->setHeight(adjustHeight(add));

					rebalance(temp);
					return;
				}
				temp = temp->getRight();
			}
			else if(k == temp->getKey())
			{
				temp->setValue(v);
				return;
			}
		}
		if(k < temp->getKey())
		{
			if(temp->getLeft() == NULL)
			{
				AVLNode<Key, Value>* add = new AVLNode<Key, Value>(k, v, temp);
				temp->setLeft(add);
				add->setHeight(adjustHeight(add));

				rebalance(temp);
				return;
			}
			temp = temp->getLeft();
		}
		else if(k > temp->getKey())
		{
			if(temp->getRight() == NULL)
			{
				AVLNode<Key, Value>* add = new AVLNode<Key, Value>(k, v, temp);
				temp->setRight(add);
				add->setHeight(adjustHeight(add));

				rebalance(temp);
				return;
			}
			temp = temp->getRight();
		}
		else if(k == temp->getKey())
		{
			temp->setValue(v);
			return;
		}
	}

}

/**
* Remove function for a given key. Finds the node, reattaches pointers, and then balances when finished. 
*/
template<typename Key, typename Value>
void AVLTree<Key, Value>::remove(const Key& key)
{
	// TODO
	AVLNode<Key, Value>* rem = static_cast<AVLNode<Key, Value>*>(this->internalFind(key));

	if(!rem)
	{
		return;
	}

	if(this->mRoot->getKey() == key)
	{
		this->removeNode(this->mRoot, key);
		rebalance(static_cast<AVLNode<Key, Value>*>(this->mRoot));
	}
	else
	{
		rebalance(static_cast<AVLNode<Key, Value>*>(this->removeNode(this->mRoot, key)));
	}
}

template<typename Key, typename Value>

int AVLTree<Key, Value>::adjustHeight(AVLNode<Key, Value>* node)
{
	if(node == NULL)
	{
		return -1;
	}
	else
	{
		return 1 + std::max(adjustHeight(node->getLeft()), adjustHeight(node->getRight()));
	}
}

template<typename Key, typename Value>
void AVLTree<Key, Value>::rebalance(AVLNode<Key, Value>* node)
{
	int right = 0;
	int left = 0;

	node->setHeight(adjustHeight(node));

	if(node->getRight() != NULL)
	{
		node->getRight()->setHeight(adjustHeight(node->getRight()));
		right = node->getRight()->getHeight() + 1;
	}
	if(node->getLeft() != NULL)
	{
		node->getLeft()->setHeight(adjustHeight(node->getLeft()));
		left = node->getLeft()->getHeight() + 1;
	}

	int balance = right - left;

	if(balance == -2)
	{
		if(node->getLeft()->getRight() == NULL)
		{
			node = rotateR(node);
		}
		else if(node->getLeft()->getLeft() == NULL)
		{
			node = rotateLR(node);
		}
		else if(node->getLeft()->getLeft()->getHeight() >= node->getLeft()->getRight()->getHeight())
		{
			node = rotateR(node);
		}
		else
		{
			node = rotateLR(node);
		}
	}
	else if(balance == 2)
	{
		if(node->getRight()->getLeft() == NULL)
		{
			node = rotateL(node);
		}
		else if(node->getRight()->getRight() == NULL)
		{
			node = rotateRL(node);
		}
		else if(node->getRight()->getRight()->getHeight() >= node->getRight()->getLeft()->getHeight())
		{
			node =rotateL(node);
		}
		else
		{
			node = rotateRL(node);
		}
	}

	if(node->getParent() != NULL)
	{
		rebalance(node->getParent());
	}
	else
	{
		this->mRoot = node;
	}
}

//left rotation of node
template<typename Key, typename Value>
AVLNode<Key, Value>* AVLTree<Key, Value>::rotateL(AVLNode<Key, Value>* node)
{
	AVLNode<Key, Value>* temp = node->getRight();
    
    node->setRight(temp->getLeft()); 
    temp->setParent(node->getParent());

    AVLNode<Key, Value>* par = temp->getParent();
 
    if (node->getRight() != NULL)
    {
        node->getRight()->setParent(node);
    }
 
    temp->setLeft(node);
    node->setParent(temp);
 
    if (par != NULL) 
    {
        if (par->getRight() == node) 
        {
            par->setRight(temp);
        }
        else 
        {
            par->setLeft(temp);
        }
    }
 	return temp;
}

//Same as previous method but flipped Left and Right methods
template<typename Key, typename Value>
AVLNode<Key, Value>* AVLTree<Key, Value>::rotateR(AVLNode<Key, Value>* node)
{
	AVLNode<Key, Value> *temp = node->getLeft();

    node->setLeft(temp->getRight()); 
    temp->setParent(node->getParent());

    AVLNode<Key, Value>* par = temp->getParent();
 
    if (node->getLeft() != NULL)
    {
        node->getLeft()->setParent(node);
    }
 
    temp->setRight(node);
    node->setParent(temp);
 
    if (par != NULL) 
    {
        if (par->getRight() == node) 
        {
            par->setRight(temp);
        }
        else 
        {
            par->setLeft(temp);
        }
    }
    return temp;
}

//left and then right rotation of node
template<typename Key, typename Value>
AVLNode<Key, Value>* AVLTree<Key, Value>::rotateLR(AVLNode<Key, Value>* node)
{
	AVLNode<Key, Value>* leftRot = rotateL(node->getLeft());

	node->setLeft(leftRot);

	return rotateR(node);
}

//right and then left rotation of node
template<typename Key, typename Value>
AVLNode<Key, Value>* AVLTree<Key, Value>::rotateRL(AVLNode<Key, Value>* node)
{	
	AVLNode<Key, Value>* rightRot = rotateR(node->getRight());

	node->setRight(rightRot);

	return rotateL(node);
}
/*
------------------------------------------
End implementations for the AVLTree class.
------------------------------------------
*/

#endif
