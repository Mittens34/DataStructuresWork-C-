my answers to problem one are in the file titled "IMG-2813.jpg"
please download for the full image

Please see answers to analysis in analysis/README.md
