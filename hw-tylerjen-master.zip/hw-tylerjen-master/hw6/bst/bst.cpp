#include "bst.h"
#include <iostream>

using namespace std;

int main()
{
	BinarySearchTree<int, int> test;

	pair<int, int> test1;
	test1.first = 7;
	test1.second = 4;
	pair<int, int> test2;
	test2.first = 4;
	test2.second = 5;
	pair<int, int> test3;
	test3.first = 2;
	test3.second = 6;
	pair<int, int> test4;
	test4.first = 8;
	test4.second = 20;
	pair<int, int> test5;
	test5.first = 1;
	test5.second = 2;
	pair<int, int> test6;
	test6.first = 3;
	test6.second = 19;
	pair<int, int> test7;
	test7.first = 20;
	test7.second = 17;

	test.insert(test1);
	test.print();
	
	test.insert(test2);
	test.print();
	test.insert(test3);
	test.print();
	test.insert(test4);
	test.print();
	test.insert(test5);
	test.print();
	test.insert(test6);
	test.print();
	test.insert(test7);

	test.print();

	test.removeNode(test.getRoot(), 2);

	test.print();

	test.removeNode(test.getRoot(), 1);

	test.print();

	test.removeNode(test.getRoot(), 20);

	test.print();

	test.clear();

	test.print();

	return 0;
}
