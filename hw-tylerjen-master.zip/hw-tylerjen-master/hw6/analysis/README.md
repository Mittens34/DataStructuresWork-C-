Which sizes of input cases did you test your program on? This would apply both to the 
length m of the strings in the file, and the number n of strings/queries.

Test 1: average string length 2-4 (random), 1330 strings (Declaration of Independence)
Test 2: average string length 8, 501 strings (Words 8 letters long in alphabetical order)
Test 3: average string length 3, 10000 numbers (numbers ascending 1-10000)
Test 4: average string length random, 699 insertions (random data)
Test 5: average string length random, 19959 insertions (constitution)

For each of the two data structures, report how long each of your input cases took. 
How long did it take per operation? Did it depend on the parameters, and if so how? 
How did that depend on the parameters?

Test 1: 
AVL: 0.062279 seconds
Splay: 0.004208 seconds
Splay expensive: 192

Test 2:
AVL: 0.033884 seconds
Splay: 0.000565 seconds
Splay expensive: 2

Test 3: 
10000 insertions
AVL: 13.2305 seconds
Splay: 0.013435 seconds
Splay expensive: 10

Test 4:
AVL: 0.024516 seconds
Splay: 0.002919 seconds
Splay expensive: 2

Test 5:
AVL: 1.63832 seconds
Splay: 0.047989 seconds
Splay expensive: 976

When the data was sorted it was way worse for AVL than splay but when the data was random Splay had way more bad insertions. Additionally longer strings caused the splay to have more bad insertions.

Explain why you think the results turned out the way they did.

Test 1,2 and 4 do not have enough data points to make splay inefficient but the longer words and random datasets proved to create more bad insertions. Test 5 is extremely random and therefore bad for splay but AVL can handle it with its normal log(n) runtime: if this dataset was larger splay would have a more significant runtime. Finally test 3 is just numbers in order (1-34500), which is horrible for AVL but very efficient for the splay

How do you think the running time would compare if you were to implement and analyze
the following data structures? Briefly justify each, although you do not need to 
quantify how much slower/faster with any specificity.

Unsorted List = better for AVL because in general it will keep log(n) while splay can be linear

Sorted list = better for splay because it needs to rotate very little 

Binary search tree, non-rotating variety = better for AVL because this tree could be extermely unbalanced
and inefficient for the splay

Hash Table, with universal hash function = easy to traverse in order and therefore better for splay