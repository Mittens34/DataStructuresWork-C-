#include "../avl/avlbst.h"
#include "../splay/splay.h"
#include <iostream>
#include <ctime>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

int main(int argc, char* argv[])
{
	clock_t startAVL;
	clock_t startSplay;

	double durationAVL = 0;
	double durationSplay = 0;
	int insertions = 0;
	int badInsertions = 0;

	vector<string> data;

	if(argc < 3)
	{
		cerr << "Please provide an input and output file." << endl;
		return 1;
	}

	ifstream in;
	in.open(argv[1]);
	if(!in)
	{
		cout << "invalid input file" << endl;
		return 1;
	}

	ofstream out;
	out.open(argv[2]);
	if(!out)
	{
		cout << "invalud output file" << endl;
		return 1;
	}

	while(! in.eof())
	{
		string add = "";
		in >> add;
		data.push_back(add);
		insertions++;
	}

	pair<string, int> dataString;

	AVLTree<string, int> avl;
	SplayTree<string, int> splay;

	startAVL = clock();

	for(unsigned int i = 0; i < data.size(); i++)
	{
		dataString.first = data[i];
		dataString.second = 0;
		avl.insert(dataString);
	}

	durationAVL = (clock() - startAVL) / (double) CLOCKS_PER_SEC;

	startSplay = clock();

	for(unsigned int j = 0; j < data.size(); j++)
	{
		dataString.first = data[j];
		dataString.second = 0;
		splay.insert(dataString);
	}
	badInsertions = splay.report();
	durationSplay = (clock() - startSplay) / (double) CLOCKS_PER_SEC;

	out << insertions << " insertions" << endl;
	out << "AVL: " << durationAVL << " seconds" << endl;
	out << "Splay: " << durationSplay << " seconds" << endl;
	out << "Splay expensive: " << badInsertions << endl;

	out.close();

	return 0;
}
