#include "company.hpp"
#include <string>
#include <iostream>
#include <vector>

using namespace std;

CompanyTracker::CompanyTracker (int n)
  // initializes the tracker with n students and their 1-person companies
{
  numCompanies = n;
  companies = new Company* [numCompanies];
  for (int i = 0; i < numCompanies; ++i)
  {
      companies[i] = new Company ();
  }
  delete[] companies;
}

CompanyTracker::~CompanyTracker ()
  // deallocates all dynamically allocated memory
{
  // your implementation goes here
  for(int i = 0; i < numCompanies; i++)
  {
    delete companies[i];
  }
  delete[] companies;
}

void CompanyTracker::merge (int i, int j)
  /* Merges the largest companies containing students i and j,
     according to the rules described above.
     That is, it generates a new Company object which will
     become the parent company of the largest companies currently
     containing students i and j.
     If i and j already belong to the same company (or are the same),
     merge doesn't do anything.
     If either i or j are out of range, merge doesn't do anything. */
{
  // your implementation goes here
  if(i > numCompanies-1 || j > numCompanies-1 || inSameCompany(i, j))
  {
    return;
  }

  Company* bigA = new Company();
  Company* bigB = new Company();
  bigA = companies[i];
  bigB = companies[j];

  while(bigA->parent != nullptr)
  {
    bigA = bigA->parent;
  }
  while(bigB->parent != nullptr)
  {
    bigB = bigB->parent;
  }

  Company* newParent = new Company(bigA, bigB);
  bigA->parent = newParent;
  bigB->parent = newParent;

  delete bigB;
  delete bigA;

}

void CompanyTracker::split (int i)
  /* Splits the largest company that student i belongs to,
     according to the rules described above.
     That is, it deletes that Company object, and makes sure that
     the two subcompanies have no parent afterwards.
     If i's largest company is a 1-person company, split doesn't do anything.
     If i is out of range, split doesn't do anything. */
{
  // your implementation goes here
  if(i > numCompanies-1)
  {
    return;
  }
  Company* temp = new Company();
  temp = companies[i];
  while(temp-> parent != nullptr)
  {
    temp = temp->parent;
  }

  if(temp->merge1 == nullptr || temp->merge2 == nullptr)
  {
    return;
  }

  temp->merge1->parent = nullptr;
  temp->merge2->parent = nullptr;
  temp->merge2 = nullptr;
  temp->merge1 = nullptr;

  delete temp;
}

bool CompanyTracker::inSameCompany (int i, int j)
  /* Returns whether students i and j are currently in the same company.
     Returns true if i==j.
     Returns false if i or j (or both) is out of range. */
{
  // your implementation goes here
  if(i > numCompanies-1 || j > numCompanies-1)
  {
    return false;
  }

  Company* bigA = new Company();
  Company* bigB = new Company();
  bigA = companies[i];
  bigB = companies[j];

  while(bigA->parent != nullptr)
  {
    bigA = bigA->parent;
  }
  while(bigB->parent != nullptr)
  {
    bigB = bigB->parent;
  }

  if(i == j || bigB == bigA)
  {
    return true;
  }
  else
  {
    return false;
  }
}
