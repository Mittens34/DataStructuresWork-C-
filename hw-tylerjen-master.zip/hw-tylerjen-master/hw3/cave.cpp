#include <string>
#include <stack>
#include <iostream>
#include <fstream>

using namespace std;

int determineDistance(istream& in)
{
	string line;
	stack<string> directions;
	while(getline(in, line))
	{
		if(directions.empty())
		{
			directions.push(line);
		}
		else
		{
			if(line == "N")
			{
				if(directions.top() == "S")
				{
					directions.pop();
				}
				else
				{
					directions.push(line);
				}
			}
			else if(line == "S")
			{
				if(directions.top() == "N")
				{
					directions.pop();
				}
				else
				{
					directions.push(line);
				}
			}
			else if(line == "E")
			{
				if(directions.top() == "W")
				{
					directions.pop();
				}
				else
				{
					directions.push(line);
				}
			}
			else if(line == "W")
			{
				if(directions.top() == "E")
				{
					directions.pop();
				}
				else
				{
					directions.push(line);
				}
			}
		}
	}
	return directions.size();
}

int main(int argc, char* argv[])
{
	if(argc < 2)
	{
		cerr << "Please provide an input file." << endl;
		return 1;
	}

	ifstream input(argv[1]);
	cout << determineDistance(input) << endl;
}