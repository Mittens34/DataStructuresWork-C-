#include <vector>
#include <string>
#include <iostream>

using namespace std;

void generateHelper(vector<string>& shuffle, string temp, string in, size_t length) 
{
	
	if(length == temp.size())
	{
		shuffle.push_back(temp);
	}
	else
	{
		for(size_t i = 0; i < in.size(); i++)
		{
			string er = in;
			string add = temp;
			generateHelper(shuffle, add + in.at(i), er.erase(i, 1), length);
		}
	}
}


void permutations(string in) 
{
	vector<string> shuffle;
	generateHelper(shuffle, "", in, in.size());

	for(size_t i = 0; i < shuffle.size(); i++)
	{
		cout << shuffle[i] << endl;
	}
}
