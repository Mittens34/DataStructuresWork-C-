Problem 1-3 -> in hw3.txt

Problem 4 -> To run permutations run "./permuations" with the string you want to test

Problem 5 -> run cave with "./cave file_name" after typing make cave

Problem 6-> company.cpp and company.hpp in company folder
