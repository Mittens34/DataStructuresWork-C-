1: Course Policies

Part (a) 1, 4

Part (b) all the above

Part (c) all the above

Part (d) 2

Part (e) 2 and 3

2: Git Quiz

DOUBLE CHECK Part (a) all the above

Part (b) 1,2

Part (c) (1) git add hw1q2b.cpp  (2) git log --pretty=oneline

Part (d) it will commit the three files and add them to the repository

Part (e) git clone git@github.com:usc-csci104-fall2019

3: More Git Questions

Part (a) the status is unmodified

Part (b) fun_problem.txt is untracked; README.md is modified

Part (c) fun_problem.txt and README.md are staged

Part (d) fun_problem.txt and README.md are modified

Part (e) fun_problem.txt is changed to its state before the last echo and it is unmodified because checkout command will revert the file back to the last commit.

Part (f) README.md is modified but not staged
