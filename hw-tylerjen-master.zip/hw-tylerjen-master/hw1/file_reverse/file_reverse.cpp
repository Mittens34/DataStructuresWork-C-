#include <iostream>
#include <fstream>
using namespace std;

int main(int argc, char* argv[])
{
	//open file
	ifstream file;
    file.open(argv[1]);

    //get number of chars in file
    int x;
    file >> x;

    //forces next line on file
    char newline;
    file.get(newline);


    //temp array to print chars in reverse
    char *array = new char[x];

    //read each char in file
    for(int i = 0; i < x; i++)
    {
    	file.read(array + i, 1);
    }
    

    //print elements in reverse order 
    for(int z = x - 1; z >= 0; z--)
    {
        cout << array[z];  

        if (z == 0)
        {
        	cout << endl;
        } 
    }

    //clear memory
    delete [] array;
}
