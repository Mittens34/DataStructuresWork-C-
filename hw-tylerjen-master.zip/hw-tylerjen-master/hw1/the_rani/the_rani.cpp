#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <string>

class TheRani {
public:
    TheRani(char* input_path, char* output_path);
    ~TheRani();


    // Call execute and handles exceptions
    void main();

private:
    int experiment_count;       // You will need to track the number of experiments
    int* subject_counts;        // For each, the number of subjects
    string** subject_history;   // And for each subject, their history

    ifstream input;             // Input file stream
    ofstream output;            // Output file stream
    void start(int n);
    void add();
    void move(int x, int y, int n, int m);
    void query(int x, int n);

    // Called in the main method
    void execute(const string& line);

    // Possible helper: deallocate all current members
};

TheRani::TheRani(char* input_path, char* output_path) : experiment_count(0), input(input_path), output(output_path) {
}

TheRani::~TheRani() {

}

// Possible helper: read an integer argument from a stream

void TheRani::main() {
    string line;
    while (getline(input, line)) {
        try {
            this->execute(line);
        } catch(exception& e) {
            // If you use exceptions, make sure the line number is printed here
            this->output << "Error on line ?: " << e.what() << endl;
        }
    }
}

void TheRani::start(int n)
{
	if(n < 0)
	{
		throw out_of_range("argument out of range");
	}

	//contstructs all private variables
	subject_history = new string*[1];

	subject_history[0] = new string[n];

	subject_history[0][0] = "";

	subject_counts = new int[1];

	subject_counts[0] = n;

	for(int i = 0; i < subject_counts[0]; i++)
	{
		subject_history[0][i] = i;
	}

	experiment_count = 1;
}

void TheRani::add()
{
	if(experiment_count == 0)
	{
		cout << "no subjects yet";
	}
	else
	{
	
	experiment_count++;
	string** temp = new string*[experiment_count];

	//adds everything to newly sized array and deletes old array
	for(int i = 0; i < experiment_count - 1; i++)
	{	
		temp[i] = new string[subject_counts[i]];
		for(int j = 0; j < subject_counts[i]; j++)
		{
			temp[i][j] = subject_history[i][j];

		}
		delete [] subject_history[i];

	}
	delete [] subject_history;
	//adds new experiment
	temp[experiment_count-1] = new string[0];

	int* temp_count = new int[experiment_count];
	for(int z = 0; z < experiment_count-1; z++)
	{
		temp_count[z] = subject_counts[z];
	}
	temp_count[experiment_count-1] = 0;
	delete [] subject_counts;

	//sets temp as new arrays
	subject_counts = temp_count;
	subject_history = temp;
	}
} 

void TheRani::move(int x, int y, int n, int m)
{
	
	
	if(experiment_count == 0)
	{
		cout << "no subjects yet";
		
	}
	else if(n > m)
	{
		cout << "invalid range of subjects to move";
		

	}
	else if(x < 0 || y < 0 || n < 0 || m < 0)// || m >= subject_counts[x] || x >= experiment_count || y >= experiment_count)
	{
		throw out_of_range("argument out of range");

		
	}
	else
		
	{
	if(x == y)
	{
		//if same expirememt columns it swaps last array with element m and works its way down
		string stor = "";
		int co = m;
		int last = subject_counts[x] - 1;
		while(co >= n)
		{
			stor = subject_history[x][last];
			subject_history[x][last] = subject_history[x][co];
			subject_history[x][co] = stor;
			last--;
			co--;
		}

	}
	else
	{

	string** temp = new string*[experiment_count];
	int numSubjectsMoved = m - n + 1;
	//makes temp array with expirement y column longer length
	for(int i = 0; i < experiment_count; i++)
	{	
		if(i == y)
		{
			temp[i] = new string[subject_counts[i] + numSubjectsMoved];
		}
		else
		{
			temp[i] = new string[subject_counts[i]];
		}
		for(int j = 0; j < subject_counts[i]; j++)
		{
			temp[i][j] = subject_history[i][j];

		}
	}
	//moves n-m elements to new spot
	int previousSubjects = subject_counts[y];
	for(int start = n; n <= m; start++)
	{
		temp[y][previousSubjects] = subject_history[x][start];
		previousSubjects++;
	}
	

	int oversize = subject_counts[x] - m;
	delete [] temp[x];
	temp[x] = new string[subject_counts[x] - numSubjectsMoved];

	for(int c = 0; c < n; c++)
	{	
		temp[x][c] = subject_history[x][c];
	}
	int counter = 0;
	//resets column x to normal order (takes elements in higher spots than m and moves them down)
	while(oversize > 0)
	{
		temp[x][n + counter] = subject_history[x][m + 1 + counter];
		oversize--;
		counter++;
	}
	//deletes old array
	for(int del = 0; del < experiment_count; del++)
	{
		delete [] subject_history[del];
	}
	delete [] subject_history;
	subject_history = temp;

	subject_counts[y] = numSubjectsMoved + subject_counts[y];
	subject_counts[x] = subject_counts[x] - numSubjectsMoved;
	}
	}
}

void TheRani::query(int x, int n)
{
	if(experiment_count == 0)
	{
		cout << "no subjects yet";
	}
	else if(x < 0 || n < 0)// || x >= experiment_count || n >= subject_counts[x])
	{
		throw out_of_range("argument out of range");
	}
	else
	{
		//displays subject history
		output << subject_history[x][n] << endl;
	}
}

void TheRani::execute(const string& line) {
    string command;
    stringstream stream(line);  // Initialize the stream with the line
    stream >> command;          // Read the first word, which is the command

    if (command == "START") {   // This code should be edited for error checking
        int subject_pool_count;
        stream >> subject_pool_count;
        if (subject_pool_count < 0) {
            throw out_of_range("argument out of range");
        }
        this->start(subject_pool_count);
        // Your code here

    } // else if (more conditions) { ...
    else if(command == "ADD")
    {
    	this-> add();
    }
    else if(command == "MOVE")
    {
    	
    	int x,y,n,m;
    	stream >> x;
    	stream >> y;
    	stream >> n;
    	stream >> m;
    	
    	this-> move(x,y,n,m);
    }
    else if(command == "QUERY")
    {
    	int x, n;
    	stream >> x;
    	stream >> n;
    	this-> query(x,n);
    }
    else
    {
    	cout << "command does not exist";
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cerr << "Please provide an input and output file!" << endl;
        return 1;
    }

    TheRani tr(argv[1], argv[2]);
    tr.main();
    return 0;
}
