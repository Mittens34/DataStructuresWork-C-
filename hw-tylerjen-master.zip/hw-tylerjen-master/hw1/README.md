Unfortunately, I had an error with my move function that was setting off a segmentation fault.
I have been using gdb to try and find the root of the problem. Additionally, I went into office hours
and was still unable to fix the error today. The error being displayed mentioned a file reading error.
Due to this error, I have been unable to test or run my move function. Even with the error I still believe 
the process for my move makes sense...

check if experiments are the same
run an algorithm to separately handle moving the subjects to the last positions

else
run algorithm to adjust subject_history and subject_count

Obviously something in my algorithm is incorrect and causing this segmentation fault. Other than this error
my file_reverse should be functioning properly. 
