#ifndef INTERPRETER_HPP
#define INTERPRETER_HPP

#include <iostream>
#include <vector>
#include <stack>
#include <map>
#include "arithmetic.h"
#include "boolExpression.h"

class Interpreter {
public:
    Interpreter(std::istream& in);
    ~Interpreter();
	NumericExpression* parseExpression(std::string line);
	BoolExpression* parseBoolExpression(std::string line);
    void write(std::ostream& out);
    std::string removeSpaces(std::string str);
    std::string removeParent(std::string str , int arg);

private:
    void parse(std::istream& in);
    std::vector<std::string> output;
    std::stack<int> returnCall;
    std::map<int, std::string> input;
    std::map<std::string, int> variables;
    std::map<std::string, std::map<int, int> > arrayList;
};

#endif
