#ifndef BOOLEXPRESSION_HPP
#define BOOLEXPRESSION_HPP

#include <string>
#include "arithmetic.h"

class BoolExpression {
public:
    virtual ~BoolExpression() {}
    virtual std::string format() const = 0;
    virtual bool execute() const = 0;
};

class EqualsExpression : public BoolExpression
{
public:
    EqualsExpression(NumericExpression* left, NumericExpression* right);
    virtual ~EqualsExpression();
    virtual std::string format() const;
    virtual bool execute() const;
private:
    NumericExpression* left;
    NumericExpression* right;
};

class GreaterExpression : public BoolExpression
{
public:
    GreaterExpression(NumericExpression* left, NumericExpression* right);
    virtual ~GreaterExpression();
    virtual std::string format() const;
    virtual bool execute() const;
private:
    NumericExpression* left;
    NumericExpression* right;
};

class LesserExpression : public BoolExpression
{
public:
    LesserExpression(NumericExpression* left, NumericExpression* right);
    virtual ~LesserExpression();
    virtual std::string format() const;
    virtual bool execute() const ; 
private:
    NumericExpression* left;
    NumericExpression* right;
};

#endif