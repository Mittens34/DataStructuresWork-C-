#include "arithmetic.h"

using namespace std;

AdditionExpression::AdditionExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

AdditionExpression::~AdditionExpression() {
    delete this->left;
    delete this->right;
}

string AdditionExpression::format() const {
    return "(" + this->left->format() + " + " + this->right->format() + ")";
}

int AdditionExpression::execute() const {
    return (this->left->execute() + this->right->execute());
}

SubtractionExpression::SubtractionExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

SubtractionExpression::~SubtractionExpression() {
    delete this->left;
    delete this->right;
}

string SubtractionExpression::format() const {
    return "(" + this->left->format() + " - " + this->right->format() + ")";
}

int SubtractionExpression::execute() const {
    return (this->left->execute() - this->right->execute());
}

MultiplicationExpression::MultiplicationExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

MultiplicationExpression::~MultiplicationExpression() {
    delete this->left;
    delete this->right;
}

string MultiplicationExpression::format() const {
    return "(" + this->left->format() + " * " + this->right->format() + ")";
}

int MultiplicationExpression::execute() const {
    return (this->left->execute() * this->right->execute());
}

DivisionExpression::DivisionExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

DivisionExpression::~DivisionExpression() {
    delete this->left;
    delete this->right;
}

string DivisionExpression::format() const {
    return "(" + this->left->format() + " / " + this->right->format() + ")";
}

int DivisionExpression::execute() const {
    return (this->left->execute() / this->right->execute());
}

ConstantExpression::ConstantExpression(std::string val)
{
    value = val;
}

ConstantExpression::~ConstantExpression()
{

}

string ConstantExpression::format() const 
{
    return value;
}

int ConstantExpression::execute() const
{
    if(value.at(0) == '-')
    {
        string num = value.substr(1);
        int val = stoi(num);
        return val * (-1);
    }
    else
    {
        return stoi(value);
    }
}