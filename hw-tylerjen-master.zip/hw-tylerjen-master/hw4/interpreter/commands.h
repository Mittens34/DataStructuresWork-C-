#ifndef COMMANDS_HPP
#define COMMANDS_HPP

#include <string>
#include "arithmetic.h"
#include "boolExpression.h"
#include "variable.h"
#include "array.h"
#include "integer.h"

class Commands 
{
public:
    virtual std::string format() const = 0;
};

class Print : public Commands
{
public:
    Print(NumericExpression* left);
    virtual ~Print();

    virtual std::string format() const;

private:
    NumericExpression* left;
};

class Let: public Commands 
{
public:
    Let(NumericExpression* l, Variable* v);
    virtual ~Let();

    virtual std::string format() const;

private:
    NumericExpression* left;
    Variable* var;
};

class Goto : public Commands
{
public:
    Goto(int ln);
    virtual ~Goto();

    virtual std::string format() const;

private:
    int ln;
};

class If : public Commands
{
public:
    If(BoolExpression* left, int ln);
    virtual ~If();
    virtual std::string format() const;

private:
    BoolExpression* left;
    int ln;
};

class Gosub : public Commands
{
public:
    Gosub(int next);
    virtual ~Gosub();
    virtual std::string format() const;

private:
    //LineNumber* previous;
    int next;
};

class Return : public Commands
{
public:
    Return();
    virtual ~Return();
    virtual std::string format() const;

private:
    
};

class End 
{
public:
    End();
    virtual ~End();
    virtual std::string format() const;
};


#endif
