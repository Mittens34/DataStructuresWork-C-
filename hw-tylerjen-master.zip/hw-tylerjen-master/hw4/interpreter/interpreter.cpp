#include "interpreter.h"
#include <vector>
#include "arithmetic.h"
#include "commands.h"
#include "variable.h"
#include "boolExpression.h"
#include "integer.h"
#include "array.h"
#include <sstream>
#include <stack>
#include <algorithm>

using namespace std;

Interpreter::Interpreter(std::istream& in) 
{
    stack<int> returnCall;
    map<int, string> input;
    map<string, int> variables;
    map<string, map<int, int> > arrayList;

    vector<string> output;

    this->parse(in);
}

Interpreter::~Interpreter() 
{

}

void Interpreter::parse(std::istream& in) 
{
    string line;
    while (getline(in, line)) 
    {
        size_t line_number;
        stringstream stream(line);
        stream >> line_number;
        // Your code here

        string lineString;
        getline(stream, lineString);

        input[line_number] = lineString;


    }

    map<int, string>::iterator it = input.begin();

    while(it != input.end())
    {
        stringstream com(it->second);
        string command;
        com >> command;
        int prevLine = it->first;

        if(command == "PRINT")
        {
            string nexp;
            getline(com, nexp);

            int prin = parseExpression(nexp)->execute();
            string add = to_string(prin);
            output.push_back(add);
            it++;
            
        }
        else if(command == "LET")//also let array
        {
            string restOfLine;
            getline(com, restOfLine);
            size_t endArray = restOfLine.find("]");
            size_t startArray = restOfLine.find('[');
            string nexp;
            string var;
            if(endArray != std::string::npos)
            {
                nexp = restOfLine.substr(startArray+1, endArray - startArray -1);
                string set = restOfLine.substr(endArray+1);
                var = restOfLine.substr(0, endArray+1);
                var = removeSpaces(var);

                map<int,int> array;
                array[parseExpression(nexp)->execute()] = parseExpression(set)->execute();

                arrayList[var] = array;
            }
            else
            {
                stringstream getRest(restOfLine);
                getRest >> var;
                getline(getRest, nexp);
                variables[var] = parseExpression(nexp)->execute();
            }
            it++;
        }
		else if(command == "GOTO")//done
		{
            int lineJump;
            com >> lineJump;
            
            it = input.find(lineJump);
            if(it == input.end())
            {
                output.push_back("Error in Line <" + to_string(prevLine) + ">: GOSUB to non-existent line <" + to_string( it->first ) + ".");
                it = input.end();
            }
		} 
		else if(command == "IF")
		{
            string restOfLine;
            getline(com, restOfLine);
            size_t bexpEnd = restOfLine.find("THEN");
            string lineJump = restOfLine.substr(bexpEnd + 4);
            int length = restOfLine.size() - lineJump.size() - 4;
            string nexp = restOfLine.substr(0, length);
            
            stringstream lineChange(lineJump);
            int lineJumpNumber;
            lineChange >> lineJumpNumber;

            if(parseBoolExpression(nexp)->execute())
            {

                it = input.find(lineJumpNumber);
                if(it == input.end())
                {
                    output.push_back("Error in Line <" + to_string(prevLine) + ">: GOSUB to non-existent line <" + to_string( it->first ) + ".");
                    it = input.end();
                }
            }
            else
            {
                it++;
            }
		}
		else if(command == "GOSUB")//done
		{
            int lineJump;
            com >> lineJump;
            
            returnCall.push(lineJump);
            it++;
		}
		else if(command == "RETURN")//done
		{
            if(returnCall.empty())
            {
                output.push_back("Error in Line <" + to_string( it->first ) + ">: No matching GOSUB for RETURN.");
                it = input.end();
            }
            else
            {
                it = input.find(returnCall.top());
                if(it == input.end())
                {
                    output.push_back("Error in Line <" + to_string(prevLine) + ">: GOSUB to non-existent line <" + to_string( it->first ) + ".");
                    it = input.end();
                }
                else
                {
                    it = input.find(returnCall.top());
                    returnCall.pop();
                }
            }
		}
        else if(command == "END")//done
        {
        	it = input.end();
        }

    }
}

NumericExpression* Interpreter::parseExpression(string str)
{
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    if(str.at(0) == '(')
    {
        str = str.substr(1);
    }
    if(str.at(str.size() - 1) == ')')
    {
        str = str.substr(0, str.size() - 1);
    }
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    size_t lastParent = str.rfind(')');
    size_t arrStart = str.find("[", lastParent);
    size_t arrEnd = str.find("]", lastParent);

    if(lastParent == std::string::npos)
    {
        removeParent(str, 0);
    }
    size_t pos = str.find("+",lastParent);
    size_t pos1 = str.find("-",lastParent);
    size_t pos2 = str.find("*",lastParent);
    size_t pos3 = str.find("/",lastParent);
    
    if((pos > arrStart) & (pos < arrEnd))
    {
        pos = str.find("+", arrEnd);
    }
    if((pos1 > arrStart) & (pos1 < arrEnd))
    {
        pos1 = str.find("-", arrEnd);
    }
    if((pos2 > arrStart) & (pos2 < arrEnd))
    {
        pos2 = str.find("*", arrEnd);
    }
    if((pos3 > arrStart) & (pos3 < arrEnd))
    {
        pos3 = str.find("/", arrEnd);
    }

    if(pos != std::string::npos)
    {
        string left = str.substr(0, pos);
        string right = str.substr(pos+1);
        AdditionExpression* add = new AdditionExpression(parseExpression(left),parseExpression(right));
        return add;
    }
    else if((pos1 != std::string::npos) & (str.at(pos1+1) == ' '))
    {
        string left = str.substr(0, pos1);
        string right = str.substr(pos1+1);
        SubtractionExpression* subt = new SubtractionExpression(parseExpression(left),parseExpression(right));
        return subt;
    }
    else if(pos2 != std::string::npos)
    {
        string left = str.substr(0, pos2);
        string right = str.substr(pos2+1);
        MultiplicationExpression* multi = new MultiplicationExpression(parseExpression(left),parseExpression(right));
        return multi;
    }
    else if(pos3 != std::string::npos)
    {
        string left = str.substr(0, pos3);
        string right = str.substr(pos3+1);
        DivisionExpression* div = new DivisionExpression(parseExpression(left),parseExpression(right));
        return div;
    }
    else if(arrStart != std::string::npos)
    {
        string inBrackets = str.substr(arrStart + 1, arrEnd - arrStart - 1);
        string name = str.substr(0, arrStart);
        
        map<string, map<int,int> >::iterator iter = arrayList.find(name);

        map<int,int>::iterator it = iter->second.find(parseExpression(inBrackets)->execute());


        ConstantExpression* ar = new ConstantExpression(to_string(it->second));

        return ar;
    }
    else
    {
        pos = str.rfind("+");
        pos1 = str.rfind("-");
        pos2 = str.rfind("*");
        pos3 = str.rfind("/");
        arrStart = str.find("[");
        arrEnd = str.find("]");

        if((arrEnd == str.size() - 1) & (str.find("[") < pos1))
        {
            arrStart = str.find("[");
        }
        if((arrEnd == str.size() - 1) & (str.find("[") < pos))
        {
            arrStart = str.find("[");
        }
        if((arrEnd == str.size() - 1) & (str.find("[") < pos2))
        {
            arrStart = str.find("[");
        }
        if((arrEnd == str.size() - 1) & (str.find("[") < pos3))
        {
            arrStart = str.find("[");
        }
        
        if((pos > arrStart) & (pos < arrEnd))
        {
            pos = str.find("+", arrEnd);
        }
        if((pos1 > arrStart) & (pos1 < arrEnd))
        {
            pos1 = str.find("-", arrEnd);
        }
        if((pos2 > arrStart) & (pos2 < arrEnd))
        {
            pos2 = str.find("*", arrEnd);
        }
        if((pos3 > arrStart) & (pos3 < arrEnd))
        {
            pos3 = str.find("/", arrEnd);
        }

        if(pos != std::string::npos)
        {
            string left = str.substr(0, pos);
            string right = str.substr(pos+1);
            NumericExpression* r = parseExpression(right);
            AdditionExpression* add = new AdditionExpression(parseExpression(left),r);
            return add;
        }
        else if((pos1 != std::string::npos) & (str.at(pos1+1) == ' '))
        {
            string left = str.substr(0, pos1);
            string right = str.substr(pos1+1);
            NumericExpression* r = parseExpression(right);
            SubtractionExpression* subt = new SubtractionExpression(parseExpression(left), r);
            return subt;
        }
        else if(pos2 != std::string::npos)
        {
            string left = str.substr(0, pos2);
            string right = str.substr(pos2+1);
            NumericExpression* r = parseExpression(right);
            MultiplicationExpression* multi = new MultiplicationExpression(parseExpression(left), r);
            return multi;
        }
        else if(pos3 != std::string::npos)
        {
            string left = str.substr(0, pos3);
            string right = str.substr(pos3+1);
            NumericExpression* r = parseExpression(right);
            DivisionExpression* div = new DivisionExpression(parseExpression(left), r);
            return div;
        }
        else if(arrStart != std::string::npos)
        {
            string inBrackets = str.substr(arrStart + 1, arrEnd - arrStart - 1);

            string name = str.substr(0, arrStart);
            

            map<string, map<int,int> >::iterator iter = arrayList.find(name);

            if(iter == arrayList.end())
            {
                return new ConstantExpression("0");
            }
            else
            {
                map<int,int>::iterator it = iter->second.find(parseExpression(inBrackets)->execute());

                if(it == iter->second.end())
                {
                    return new ConstantExpression("0");
                }
                else
                {
                    ConstantExpression* ar = new ConstantExpression(to_string(it->second));

                    return ar;
                }
            }
        }
        else
        {
            
            if(str.at(0) == '-')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '0')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '1')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '2')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '3')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '4')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '5')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '6')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '7')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '8')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else if(str.at(0) == '9')
            {
                ConstantExpression* con = new ConstantExpression(str);
                return con;
            }
            else
            {
                map<string, int>::iterator iter = variables.find(str);
                if(iter == variables.end())
                {
                    return new ConstantExpression("0");
                }
                ConstantExpression* con = new ConstantExpression(to_string(iter->second));
                return con;
            }
        }
    }

}

BoolExpression* Interpreter::parseBoolExpression(string str)
{
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    if(str.at(0) == '(')
    {
        str = str.substr(1);
    }
    if(str.at(str.size() - 1) == ')')
    {
        str = str.substr(0, str.size() - 1);
    }
    while(str.at(0) == ' ')
    {
        str = str.substr(1);
    }
    while(str.at(str.size()-1) == ' ')
    {
        str = str.substr(0, str.size() - 1);
    }
    size_t lastParent = str.rfind(')');


    size_t bool1 = str.find("=",lastParent);
    size_t bool2 = str.find("<",lastParent);
    size_t bool3 = str.find(">",lastParent);

    if(bool1 != std::string::npos)
    {
        string left = str.substr(0, bool1);
        string right = str.substr(bool1+1);
        EqualsExpression* equa = new EqualsExpression(parseExpression(left), parseExpression(right));
        return equa;
    }
    else if(bool2 != std::string::npos)
    {
        string left = str.substr(0, bool2);
        string right = str.substr(bool2+1);
        LesserExpression* lesse = new LesserExpression(parseExpression(left),parseExpression(right));
        return lesse;
    }
    else if(bool3 != std::string::npos)
    {
        string left = str.substr(0, bool3);
        string right = str.substr(bool3+1);
        GreaterExpression* grea = new GreaterExpression(parseExpression(left),parseExpression(right));
        return grea;
    }
    else
    {

        bool1 = str.rfind("=");
        bool2 = str.rfind("<");
        bool3 = str.rfind(">");

        if(bool1 != std::string::npos)
        {
            string left = str.substr(0, bool1);
            string right = str.substr(bool1+1);
            NumericExpression* r = parseExpression(right);
            EqualsExpression* equa = new EqualsExpression(parseExpression(left), r);
            return equa;
        }
        else if(bool2 != std::string::npos)
        {
            string left = str.substr(0, bool2);
            string right = str.substr(bool2+1);
            NumericExpression* r = parseExpression(right);
            LesserExpression* lesse = new LesserExpression(parseExpression(left),r);
            return lesse;
        }
        else
        {
            string left = str.substr(0, bool3);
            string right = str.substr(bool3+1);
            NumericExpression* r = parseExpression(right);
            GreaterExpression* grea = new GreaterExpression(parseExpression(left),r);
            return grea;
        }
    }
}

std::string Interpreter::removeSpaces(std::string str)
{
    str.erase(remove(str.begin(), str.end(), ' '), str.end());
    return str;
}

std::string Interpreter::removeParent(std::string str , int arg)
{
    if(arg == 0)
    {
        str.erase(remove(str.begin(), str.end(), '('), str.end());
        return removeParent(str, 1);
    }
    else
    {
        str.erase(remove(str.begin(), str.end(), ')'), str.end());
        return str;
    }
    
}

void Interpreter::write(std::ostream& out) 
{
    std::string space = " ";
    int si = output.size();
    for(int z = 0; z < si; z++)
    {
        out << output[z];
        out << endl;
        
    }
}