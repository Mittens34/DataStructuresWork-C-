#include "boolExpression.h"

using namespace std;

EqualsExpression::EqualsExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

EqualsExpression::~EqualsExpression() {
    delete this->left;
    delete this->right;
}

string EqualsExpression::format() const {
    return "(" + this->left->format() + " = " + this->right->format() + ")";
}

bool EqualsExpression::execute() const {
	return (this->left->execute() == this->right->execute());
}

GreaterExpression::GreaterExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {

}

GreaterExpression::~GreaterExpression() {
    delete this->left;
    delete this->right;
}

string GreaterExpression::format() const {
    return "(" + this->left->format() + " > " + this->right->format() + ")";
}

bool GreaterExpression::execute() const {
	return (this->left->execute() > this->right->execute());
}

LesserExpression::LesserExpression(NumericExpression* left, NumericExpression* right) : left(left), right(right) {
}

LesserExpression::~LesserExpression() {
    delete this->left;
    delete this->right;
}

string LesserExpression::format() const {
    return "(" + this->left->format() + " < " + this->right->format() + ")";
}

bool LesserExpression::execute() const {
	return (this->left->execute() < this->right->execute());
}