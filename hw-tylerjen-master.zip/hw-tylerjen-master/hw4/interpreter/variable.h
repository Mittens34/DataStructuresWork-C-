#ifndef VARIABLE_H
#define VARIABLE_H

#include <iostream>
#include "arithmetic.h"

class Variable : public NumericExpression
{
public:
	Variable(std::string);
	~Variable();
	std::string getName();
	std::string format() const;
	std::string name;
};

#endif