#include "commands.h"
#include <sstream>
#include <iostream>
using namespace std;

Print::Print(NumericExpression* n)
{
	left = n;
}

Print::~Print()
{
	delete left;
}

string Print::format() const 
{
	return "PRINT " + left->format();
}

Let::Let(NumericExpression* l, Variable* v)
{
	left = l;
	var = v;
}

Let::~Let()
{
	delete left;
	delete var;
}

string Let::format() const 
{
	return "LET " + var->format() + " " + left->format();
}
Goto::Goto(int line)
{
	ln = line;
}

Goto::~Goto()
{
	
}

string Goto::format() const 
{
	stringstream conv;
	conv << ln;

	return "GOTO <" + conv.str() + ">";
}

If::If(BoolExpression* l, int line)
{
	left = l;
	ln = line;
}

If::~If()
{
	delete left;
}

string If::format() const 
{
	stringstream conv;
	conv << ln;

	return "IF " + left->format() + " THEN " + "<" + conv.str() + ">";
}

Gosub::Gosub(int line)
{
	
	next = line;
}

Gosub::~Gosub()
{
	//delete previous;
}

string Gosub::format() const 
{
	stringstream conv;
	conv << next;

	return "GOSUB <" + conv.str() + ">";
}

Return::Return()
{
	
}

Return::~Return()
{
	
}

string Return::format() const 
{
	return "RETURN";
}

End::End()
{

}

End::~End()
{
	
}

string End::format() const 
{
	return "END";
}